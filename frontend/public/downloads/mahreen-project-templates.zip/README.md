# Mahreen Project Templates

Paket ini berisi tiga template dasar:

1. `project-brief.csv` — kebutuhan, tujuan, target audiens, output, anggaran, dan PIC.
2. `project-timeline.csv` — fase, aktivitas, penanggung jawab, tanggal, status, dan catatan.
3. `revision-log.csv` — riwayat revisi, keputusan, dan persetujuan.

Buka file CSV menggunakan Microsoft Excel, Google Sheets, LibreOffice Calc, atau aplikasi spreadsheet lain.
